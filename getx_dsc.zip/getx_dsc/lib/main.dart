import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'app/routes/app_pages.dart';
//MVC
//Model
//view
//Controller

void main() {
  runApp(
    GetMaterialApp(
      title: "Application",
      initialRoute: AppPages.INITIAL,
      getPages: AppPages.routes,
      theme: ThemeData.light(),
      //darkTheme: ThemeData.dark(),
      defaultTransition: Transition.rightToLeftWithFade,
    ),
  );
}
