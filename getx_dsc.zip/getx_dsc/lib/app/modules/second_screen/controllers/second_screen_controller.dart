import 'package:get/get.dart';

class SecondScreenController extends GetxController {
  List arguments = Get.arguments;
}
