import 'package:flutter/material.dart';
import 'package:get/get.dart';

class HomeController extends GetxController {
  RxInt counter = 0.obs;
  onInit() {
    super.onInit();
  }

  showSnackbar() {
    Get.bottomSheet(Container(
      height: Get.height / 2,
      color: Colors.blue,
    ));
  }
}
