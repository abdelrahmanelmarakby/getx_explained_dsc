import 'package:bmi/app/routes/app_pages.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/home_controller.dart';

class HomeView extends GetView<HomeController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: FloatingActionButton(
          child: Icon(Icons.add),
          onPressed: () => Get.toNamed(Routes.SECOND_SCREEN),
        ),
        drawer: Drawer(),
        body: Container(
          height: Get.height,
          width: Get.width,
          child:
              Center(child: Hero(tag: "1", child: Icon(Icons.account_circle))),
        ));
  }
}
