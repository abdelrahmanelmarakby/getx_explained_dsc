import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../controllers/third_screen_controller.dart';

class ThirdScreenView extends GetView<ThirdScreenController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ThirdScreenView'),
        centerTitle: true,
      ),
      body: Center(
        child: Text(
          'ThirdScreenView is working',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
