import 'package:get/get.dart';

import 'package:bmi/app/modules/home/bindings/home_binding.dart';
import 'package:bmi/app/modules/home/views/home_view.dart';
import 'package:bmi/app/modules/second_screen/bindings/second_screen_binding.dart';
import 'package:bmi/app/modules/second_screen/views/second_screen_view.dart';
import 'package:bmi/app/modules/third_screen/bindings/third_screen_binding.dart';
import 'package:bmi/app/modules/third_screen/views/third_screen_view.dart';

part 'app_routes.dart';

class AppPages {
  static const INITIAL = Routes.HOME;

  static final routes = [
    GetPage(
      name: _Paths.HOME,
      page: () => HomeView(),
      binding: HomeBinding(),
    ),
    GetPage(
      name: _Paths.SECOND_SCREEN,
      page: () => SecondScreenView(),
      binding: SecondScreenBinding(),
    ),
    GetPage(
      name: _Paths.THIRD_SCREEN,
      page: () => ThirdScreenView(),
      binding: ThirdScreenBinding(),
    ),
  ];
}
