part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  static const HOME = _Paths.HOME;
  static const SECOND_SCREEN = _Paths.SECOND_SCREEN;
  static const THIRD_SCREEN = _Paths.THIRD_SCREEN;
}

abstract class _Paths {
  static const HOME = '/home';
  static const SECOND_SCREEN = '/second-screen';
  static const THIRD_SCREEN = '/third-screen';
}
