package com.bmi.bmi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
